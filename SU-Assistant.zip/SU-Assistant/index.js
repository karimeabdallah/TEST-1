const express = require('express');
const app = express();
const chalk = require("chalk");

app.get('/', (req, res) => {
        res.send('The Bot Was Created By bzra')
})
app.use('/ping', (req, res) => {
        res.send(new Date());
});
app.listen(3000, () => {
        console.log(chalk.red.bold('Express is ready.'))
});

process.on('unhandledRejection', (reason, p) => {
        console.log(' [antiCrash] :: Unhandled Rejection/Catch');
        console.log(reason, p);
    });
process.on("uncaughtException", (err, origin) => {
        console.log(' [antiCrash] :: Uncaught Exception/Catch');
        console.log(err, origin);
    }) 
process.on('uncaughtExceptionMonitor', (err, origin) => {
        console.log(' [antiCrash] :: Uncaught Exception/Catch (MONITOR)');
        console.log(err, origin);
    });
process.on('multipleResolves', (type, promise, reason) => {
        console.log(' [antiCrash] :: Multiple Resolves');
        //console.log(type, promise, reason);
});

const db = require("quick.db");
const ms = require("ms");
const prefix = "!";
const Discord = require("discord.js");

const { Client , MessageActionRow , MessageButton , MessageEmbed , MessageSelectMenu , Intents } = require("discord.js");


const client = new Discord.Client({
    allowedMentions: {
        parse: [
            'users',
            'roles'
        ],
        repliedUser: true
    },
    autoReconnect: true,
    disabledEvents: [
        "TYPING_START"
    ],
    partials: [
        'USER',
        'CHANNEL',
        'GUILD_MEMBER',
        'MESSAGE',
        'REACTION',
        'GUILD_SCHEDULED_EVENT'
    ],
    intents: [
        Discord.Intents.FLAGS.GUILDS,
        Discord.Intents.FLAGS.GUILD_MEMBERS,
        Discord.Intents.FLAGS.GUILD_BANS,
        Discord.Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,
        Discord.Intents.FLAGS.GUILD_INTEGRATIONS,
        Discord.Intents.FLAGS.GUILD_WEBHOOKS,
        Discord.Intents.FLAGS.GUILD_INVITES,
        Discord.Intents.FLAGS.GUILD_VOICE_STATES,
        Discord.Intents.FLAGS.GUILD_MESSAGES,
        Discord.Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
        Discord.Intents.FLAGS.GUILD_MESSAGE_TYPING,
        Discord.Intents.FLAGS.DIRECT_MESSAGES,
        Discord.Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,
        Discord.Intents.FLAGS.DIRECT_MESSAGE_TYPING,
        Discord.Intents.FLAGS.GUILD_SCHEDULED_EVENTS,
    ],
    restTimeOffset: 0
});

client.on('ready', () => {
console.log(`${client.user.tag}`)
 client.user.setActivity(`Welcome To SU Clan`, { type: 'STREAMING', url: 'https://www.twitch.tv/1Karim_Khalil1' })  
});

client.login(process.env.token).catch((err) => {
   console.log(err.message)
});

//ready message
client.on("ready", () => {
    let embed = new Discord.MessageEmbed()
.setTitle("Welcome To Bzra System")      
.setDescription(`**Im Ready Now**`)
.setColor(`#020202`) 
.setImage(`https://cdn.discordapp.com/attachments/1116869171301589136/1116870589550952448/Bot_Start.gif`)      
.setTimestamp()
    let channel = client.channels.cache.get('1162828311915941929');
    channel.send({content: `<@1116817328932397217>`, embeds : [embed]})
})

//welcome
client.on('guildMemberAdd' , async (member) => {
    let embed = new Discord.MessageEmbed()
.setThumbnail(member.user.avatarURL())
.setColor('020202') 
.setImage(`https://i.pinimg.com/originals/9f/96/11/9f9611f74902435c9626804c3c4ab3eb.gif`)
.setDescription(`**Welcome To ${member.guild.name}**

**Hey : **${member}

**Welcome To  : **\`\`${member.guild.name}\`\`

**Your Number : **\`\`${member.guild.memberCount}\`\`

**Read Rules  : ** <#923706099037777960>

**Clan News   : ** <#1116831325370982560>

**Get Role  : ** <#930083030498963467>
`)
  .setTimestamp()
    let channel = client.channels.cache.get('930082894058246194');
    channel.send({content: `${member}`, embeds : [embed]})
}) 

//invits
var { inviteTracker } = require("discord-inviter")
const tracker = new inviteTracker(client)

tracker.on("guildMemberAdd", async (member, inviter, invite) => {    let embed = new Discord.MessageEmbed()
.setThumbnail(member.user.avatarURL())
.setColor('020202') 
.setImage(`https://cdn.discordapp.com/attachments/1116869171301589136/1116870384411746344/invites.gif`)
.setDescription(`**Welcome To ${member.guild.name}**

**Hey : **<@${member.user.id}>

**Welcome To : **\`\`${member.guild.name}\`\`

**invited by** : <@!${inviter.id}>
`)
  .setTimestamp()
    let channel = client.channels.cache.get('1116825797441900634');
    channel.send({content: `${member}`, embeds : [embed]})
})

//auto role
client.on("guildMemberAdd", async (member) => {
const gid = "876535569465892884" 
const rid = "876986296852172811" 
const guild = client.guilds.cache.get(gid)
const role = await guild.roles.cache.get(rid)
await member.roles.add(role)
})

let ro1 = "1063905858234363965"//اي دي الرتبة الاولى 
let ro2 = "1063912495141634178" //الثانية 
let ro3 = "1063908463698264114" //الثالثة 
let ro4 = "1068301292004450395" //الرابعة
let ro5 = "1068301345360191518"//الخامسة
let perm = ["1","2","3","4","5"]//بدل الارقام بصلاحيات الرتب بس بنفس الترتيب
 
client.on('messageCreate', message => {
        if(message.content.toLowerCase().startsWith(prefix + "set-roles")) {
                let e = new MessageEmbed()
                .setAuthor(`Roles:-`, message.guild.iconURL({dynamic: true}))
                  .setThumbnail(message.guild.iconURL({dynamic: true})) 
                .setColor('020202') 
                .setFooter(`اضغط على اسم الرتبة ادناه لأخذها`)
                .addFields(           
                        { name: `**اضغط على الازرار ادناه لأخذ الرتب!**`, value: `
**>  رتبة :   <@&${ro1}>**
 
**>  رتبة :  <@&${ro2}>**
 
**>  رتبة :  <@&${ro3}>**
 
**>  رتبة :  <@&${ro4}>**
 
**>  رتبة :  <@&${ro5}>**
 
`},      
 
                        )
          .setImage("https://cdn.discordapp.com/attachments/1066398449479712809/1074804007995965470/Picsart_22-09-10_23-41-51-240.jpg")
 
                const b1 = new MessageActionRow()
                .addComponents(
                        new MessageButton()
                        .setCustomId("ro1")
                        .setLabel("اخبار")
                        .setStyle("SECONDARY"),
                        new MessageButton()
                        .setCustomId("ro2")
                        .setLabel("جيف واى")
                        .setStyle("SECONDARY"),
                        new MessageButton()       
                        .setCustomId("ro3")
                        .setLabel("فعاليات")
                        .setStyle("SECONDARY"),
                        new MessageButton()
                        .setCustomId("ro4")
                        .setLabel("اقتباسات") 
                        .setStyle("SECONDARY"),
                        new MessageButton()
                        .setCustomId("ro5")
                        .setLabel("اساله يوميه")
                        .setStyle("SECONDARY"),
                )
          let b2 = new MessageActionRow()
    .addComponents(
        new MessageButton()
        .setCustomId('add')                  
        .setLabel('اخذ كل الرتب!')             
        .setStyle("SUCCESS"),            
        new MessageButton()
        .setCustomId('rem')                   
        .setLabel('ازالة كل الرتب!')
        .setStyle("DANGER"),         
        )
                message.channel.send({embeds: [e], components: [b1, b2]})
                             }
})
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'ro1') {
         if(!interaction.member.roles.cache.has(ro1)) {
            interaction.member.roles.add(ro1)
let add = new MessageEmbed()
           .setTitle("**✅ |تم اضافة:**")
           .setDescription(`**> رتبة:  <@&${ro1}>**
 
**> الصلاحيات: ${perm[0]}**         
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
مبروك لقد حصلت على الرتبة. `)
            interaction.reply({embeds:[add], ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(ro1)) {
            interaction.member.roles.remove(ro1)                
 
          let rem = new MessageEmbed()
           .setTitle("**❌ |تم ازالة:**")
           .setDescription(`**> رتبة: <@&${ro1}>**
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
تم ازالة الرتبة بنجاح. `)
 
            interaction.reply({embeds:[rem], ephemeral: true, fetchReply: true});
        }
    }
});
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'ro2') {
         if(!interaction.member.roles.cache.has(ro2)) {
            interaction.member.roles.add(ro2)
let add = new MessageEmbed()
           .setTitle("**✅ |تم اضافة:**")
           .setDescription(`**> رتبة:  <@&${ro2}>**
 
**> الصلاحيات: ${perm[1]}**                    
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
مبروك لقد حصلت على الرتبة. `)
 
            interaction.reply({embeds:[add], ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(ro2)) {
            interaction.member.roles.remove(ro2)                
 
          let rem = new MessageEmbed()
           .setTitle("**❌ |تم ازالة:**")
           .setDescription(`**> رتبة: <@&${ro2}>**
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
تم ازالة الرتبة بنجاح. `)
 
            interaction.reply({embeds:[rem], ephemeral: true, fetchReply: true});
        }
    }
});
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'ro3') {
         if(!interaction.member.roles.cache.has(ro3)) {
            interaction.member.roles.add(ro3)
let add = new MessageEmbed()
           .setTitle("**✅ |تم اضافة:**")
           .setDescription(`**> رتبة:  <@&${ro3}>**
 
**> الصلاحيات: ${perm[2]}**                 
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
مبروك لقد حصلت على الرتبة. `)
 
            interaction.reply({embeds:[add], ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(ro3)) {
            interaction.member.roles.remove(ro3)                
 
          let rem = new MessageEmbed()
           .setTitle("**❌ |تم ازالة:**")
           .setDescription(`**> رتبة: <@&${ro3}>**
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
تم ازالة الرتبة بنجاح. `)
 
            interaction.reply({embeds:[rem], ephemeral: true, fetchReply: true});
        }
    }
});
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'ro4') {
         if(!interaction.member.roles.cache.has(ro4)) {
            interaction.member.roles.add(ro4)
let add = new MessageEmbed()
           .setTitle("**✅ |تم اضافة:**")
           .setDescription(`**> رتبة:  <@&${ro4}>**
 
**> الصلاحيات: ${perm[3]}**                    
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
مبروك لقد حصلت على الرتبة. `)
 
            interaction.reply({embeds:[add], ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(ro4)) {
            interaction.member.roles.remove(ro4)                
 
          let rem = new MessageEmbed()
           .setTitle("**❌ |تم ازالة:**")
           .setDescription(`**> رتبة: <@&${ro4}>**
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
تم ازالة الرتبة بنجاح. `)
 
            interaction.reply({embeds:[rem], ephemeral: true, fetchReply: true});
        }
    }
});
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'ro5') {
         if(!interaction.member.roles.cache.has(ro5)) {
            interaction.member.roles.add(ro5)
let add = new MessageEmbed()
         .setTitle("**✅ |تم اضافة:**")
           .setDescription(`**> رتبة:  <@&${ro5}>**
 
**> الصلاحيات: ${perm[4]}**                    
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
مبروك لقد حصلت على الرتبة. `)
 
            interaction.reply({embeds:[add], ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(ro5)) {
            interaction.member.roles.remove(ro5)                
 
          let rem = new MessageEmbed()
           .setTitle("**❌ |تم ازالة:**")
           .setDescription(`**> رتبة: <@&${ro5}>**
 
           `)
           .setColor("#2f3136")
.setFooter(`ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
تم ازالة الرتبة بنجاح. `)
 
            interaction.reply({embeds:[rem], ephemeral: true, fetchReply: true});
        }
    }
});
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'add') {
             interaction.member.roles.add(ro1) 
               interaction.member.roles.add(ro2) 
                 interaction.member.roles.add(ro3) 
                   interaction.member.roles.add(ro4)
 
interaction.member.roles.add(ro5)
 
let add1 = new MessageEmbed()
    .setTitle('**✅ | تم اضافة جميع الرتب.**')
.setColor('#2f3136')
            interaction.reply({embeds:[add1], ephemeral: true})
        }
});
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'rem') {
             interaction.member.roles.remove(ro1)
               interaction.member.roles.remove(ro2)
                 interaction.member.roles.remove(ro3)
                   interaction.member.roles.remove(ro4)
 
interaction.member.roles.remove(ro5)
 
let rem1 = new MessageEmbed()
    .setTitle('**❌ | تم ازالة جميع الرتب.**')
.setColor('#2f3136')
            interaction.reply({embeds:[rem1], ephemeral: true})
        }
});//*//

//line
client.on("messageCreate",  message => {
  if(message.content === "خط") {
  return message.delete(),
    message.channel.send({ content: 'https://cdn.discordapp.com/attachments/1066398449479712809/1074733183700062299/Picsart_22-09-10_23-49-08-038.jpg' })
  }
})

//auto line
let autoline = ["","","","","","","","","","",""];
client.on("messageCreate", message => {
if(message.author.bot) return;
if(autoline.includes(message.channel.id)) {
message.channel.send("https://cdn.discordapp.com/attachments/1066398449479712809/1074733183700062299/Picsart_22-09-10_23-49-08-038.jpg")
} else { return; }
})



//temporary mention
client.on("guildMemberAdd", (scooby) => {
  const channelid = "923706099037777960"
  const channel = client.channels.cache.get(channelid)
  channel.send(`🚨PLEASE READ RULES🚨 <@!${scooby.id}>`).then((message) => {
    setTimeout(() => {
      message.delete();
    },3000)
  })
})



//auto azkar
const azkar = require('azkar')
client.on('ready', () => {
    setInterval(function () {
        let channel = client.channels.cache.get("1162790779731836968")
        if (channel) {
let zekr = azkar.get()
    let embed = new MessageEmbed()
        .setTitle(`${zekr.category}`) 
        .setDescription(`>  ${zekr.zekr}`)
        .setColor("#ff0000")
        .setTimestamp()

        channel.send({ embeds: [embed] })
              
.catch((err) =>{console.log(err.message)}) 
      } 
    }, 60000 * 60)
});


const { joinVoiceChannel } = require('@discordjs/voice');
client.on("ready", async c => {
    setInterval(() => {
  const channelid = "1162827893479592086"// ايدي الروم الي تباه يثبت فيها
  const channel = client.channels.cache.get(channelid);
  if (!channel) return
  const connection = joinVoiceChannel({
    channelId: channel.id,
    guildId: channel.guild.id,
    adapterCreator: channel.guild.voiceAdapterCreator,
  });
  connection;
}, 1000 * 60);
});

setTimeout(() => {
  if (!client || !client.user) {
    console.log("Client Not Login, Process Kill")
    process.kill(1);
  } else {
    console.log("Client Login")
  }
}, 3 * 1000 * 60);

setTimeout(() => {
  process.kill(1);
  console.log("Client Login")
}, 22 * 10000 * 60);


